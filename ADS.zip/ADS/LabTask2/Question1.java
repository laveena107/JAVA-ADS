/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask2;
import java.util.Stack;

public class Question1 {
    public static String reverseString(String input) {
        Stack<Character> stack = new Stack<>();
        
        // Push characters from the input string onto the stack
        for (int i = 0; i < input.length(); i++) {
            stack.push(input.charAt(i));
        }

        // Pop characters from the stack and append them to a StringBuilder to reverse the order
        StringBuilder reversed = new StringBuilder();
        while (!stack.isEmpty()) {
            reversed.append(stack.pop());
        }

        // Convert the StringBuilder back to a string
        return reversed.toString();
    }

    public static void main(String[] args) {
        // Input string
        String input = "Hello, World!";
        
        // Reverse the string
        String reversedString = reverseString(input);
        
        // Print the reversed string
        System.out.println("Original String: " + input);
        System.out.println("Reversed String: " + reversedString);
    }
}
