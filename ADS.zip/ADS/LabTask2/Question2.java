/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask2;
import java.util.Stack;

public class Question2 {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; // Replace with your array
        
        // Calculate the midpoint of the array to split it into two parts
        int midpoint = array.length / 2;
        
        // Create two stacks
        Stack<Integer> stack1 = new Stack<>();
        Stack<Integer> stack2 = new Stack<>();
        
        // Push the first half of the array into stack1
        for (int i = 0; i < midpoint; i++) {
            stack1.push(array[i]);
        }
        
        // Push the second half of the array into stack2
        for (int i = midpoint; i < array.length; i++) {
            stack2.push(array[i]);
        }
        
        // Display the elements in the two stacks
        System.out.println("Elements in Stack 1:");
        while (!stack1.isEmpty()) {
            System.out.println(stack1.pop());
        }
        
        System.out.println("\nElements in Stack 2:");
        while (!stack2.isEmpty()) {
            System.out.println(stack2.pop());
        }
    }
}
