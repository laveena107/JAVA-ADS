
package day_01;
class myStack{
    final int SIZE =3;
    int arr[]=new int[SIZE];
    int top=-1;
    
    public boolean isEmpty(){
        if(top==-1)
            return true;
        else
            return false;
    }
    public boolean isFull(){
        if(top==SIZE-1)
            return true;
        else
            return false;
    }
    public void push(int value){
        if(isFull()){
            System.out.println("stack is full");
            
        }
        else{
            ++top;
            arr[top]=value;
        }}
        public void pop(){
        if(isEmpty()){
            System.out.println("stack is empty");
            
        }
        else{
            System.out.println(arr[top]+" is popped");
            top--;
        }
    }
        public void Peek(){
        if(isEmpty()){
            System.out.println("stack is empty");
            return;
            
          
        }
        else{
            System.out.println(arr[top]+" is peeked ");
            
          
        }
}
        public void ShowStack(){
            if(isEmpty()){
            System.out.println("stack is empty");
            return;
            
          
        }
        else{
            System.out.println(" Data in stack");
            for(int i =top;i>=0;i--){
                System.out.println(arr[i]);
            }
          }
        }
        
        }
        

public class StackImplementation {
    public static void main(String[] args) {
        myStack stack = new myStack();
        stack.push(10);
        System.out.println("10 is pushed ");
       stack.push(70);
        System.out.println("70 is pushed ");
        stack.push(30);
        System.out.println("30 is pushed ");
        stack.push(40);
        System.out.println("40 is pushed ");
        stack.pop();
        stack.Peek();
        stack.ShowStack();
       
        
    }    
}
