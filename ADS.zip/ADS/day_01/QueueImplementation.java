/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package day_01;

/**
 *
 * @author laveena
 */
class MyQueue{
final int SIZE=3;
int arr[]= new int [SIZE];
int  rear=0;
int front =0;
        
        
boolean isEmpty(){
if(rear==front){
return true;

}
else{
return false;
}
}
boolean isFull(){
    if((rear==SIZE && front==0)||(rear==front-1)){
        return true;
    }
    else{
        return false;
    }
}
public void Push(int value){
    
    if(rear==SIZE){
        System.out.println("Queue is full..");
    }
    else{
      
        arr[rear]=value;
        rear++;
    }}
    public void pop(){
        if(rear==front){
            if(front==SIZE)
                rear=front=0;
            System.out.println("Queue is empty");
            return;
                    
        }
        System.out.println("popped element is  "+arr[front]);
        front++;
    }
}

public class QueueImplementation {
    public static void main(String[] args) {
        MyQueue mq = new MyQueue();
        mq.Push(10);
        System.out.println("10 is pushed ");
        mq.Push(20);
        System.out.println("20 is pushed ");
        mq.Push(30);
        System.out.println("30 is pushed ");
        mq.pop();
        mq.Push(40);
        System.out.println("30 is pushed ");
        mq.pop();
         mq.pop();
          mq.pop();
          
        
        
    }
    
}
