/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Searching;
public class BinarySearch {
    public static void main(String[] args) {
        int[] array = { 10,23,45,70,90,100,111,123 };
        int key= 140;

        int result = binarySearch(array, 0, array.length - 1, key);

        if (result == 1) {
            System.out.println("Element "+key+" found...");
        } else {
            System.out.println("Element not found....");
        }
    }

    public static int binarySearch(int arr[], int start, int end, int key) {
        int mid;
        while (start <= end) {
            mid = (start + end) / 2;
            if (arr[mid] == key)
                return 1;
            if (arr[mid] < key)
                start = mid + 1;
            else
                end = mid - 1;
        }
        return 0;
    }
}
