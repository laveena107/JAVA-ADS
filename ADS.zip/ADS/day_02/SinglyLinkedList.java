
package day_02;
class Node{
    int data;
    Node next;
    
}
public class SinglyLinkedList {
    Node  head;
    void addFirst(int val){
        Node newNode=new Node();
        newNode.data = val;
        newNode.next=head;
        
        head=newNode; //shifting head to new node
    }
    void addLast(int val){
        Node newNode=new Node();
        newNode.data=val;
        
        if(head==null)
            head=newNode;
        else{
            Node lastNode=head;
            while(lastNode.next!=null){
                lastNode=lastNode.next;
            }
            lastNode.next=newNode;
        }
    }
    void printList(){
        Node temp=head;
        while(temp!=null)
        {
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
    
    public static void main(String[] args) {
        SinglyLinkedList sl = new SinglyLinkedList();
        sl.addFirst(10);
        sl.addFirst(20);
        sl.addFirst(30);
        sl.addLast(50);
        sl.printList();
        
        
    }

    void DeleteNode(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    boolean searchNode(int i) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
