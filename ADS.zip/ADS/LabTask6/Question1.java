/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask6;
public class Question1 {

    public static boolean isPalindrome(String str) {
        
        str = str.toLowerCase().replaceAll("\\s+", "");

        return isPalindromeRecursive(str);
    }

    private static boolean isPalindromeRecursive(String str) {
        if (str.length() <= 1) {
            return true; 
        } else {
            if (str.charAt(0) == str.charAt(str.length() - 1)) {
                 return isPalindromeRecursive(str.substring(1, str.length() - 1));
            } else {
                return false; 
            }
        }
    }

    public static void main(String[] args) {
       
        System.out.println(isPalindrome("Laveena")); 
        System.out.println(isPalindrome("abcbbcba")); 
       
    }
}
