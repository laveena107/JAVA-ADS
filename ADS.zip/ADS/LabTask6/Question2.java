/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask6;
import java.util.List;

public class Question2 {

    public static int findSum(List<Integer> list) {
        return findSumRecursive(list, 0);
    }

    private static int findSumRecursive(List<Integer> list, int index) {
        // Base case
        if (index == list.size()) {
            return 0;
        }

        return list.get(index) + findSumRecursive(list, index + 1);
    }

    public static void main(String[] args) {
     
        List<Integer> numbers = List.of(1, 2, 3, 4, 5);

        int sum = findSum(numbers);
        System.out.println("Sum of the list: " + sum); 
    }
}
