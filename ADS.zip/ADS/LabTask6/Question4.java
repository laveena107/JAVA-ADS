/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask6;
public class Question4 {

    public static double power(int base, int exponent) {
        
        if (exponent == 0) {
            return 1;
        }

        if (exponent < 0) {
            return 1 / power(base, -exponent);
        }

       
        return base * power(base, exponent - 1);
    }

    public static void main(String[] args) {
        int base = 2;
        int exponent = 5;

        int result = (int) power(base, exponent);
        System.out.println(base + " raised to the power of " + exponent + " is: " + result);
    }
}
