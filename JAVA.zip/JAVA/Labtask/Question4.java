
package Labtask;

import java.util.Scanner;

public class Question4 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a phone number: ");
        String phoneNumber = scanner.nextLine();

        if (isValidPhoneNumber(phoneNumber)) {
            System.out.println("Valid phone number!");
        } else {
            System.out.println("Invalid phone number!");
        }

        scanner.close();
    }

    private static boolean isValidPhoneNumber(String phoneNumber) {
        // Remove any non-digit characters
        String digitsOnly = phoneNumber.replaceAll("[^0-9]", "");

        // Check if the resulting string has 10 digits
        if (digitsOnly.length() == 10) {
            // You can add more specific rules based on your requirements
            return true;
        } else {
            return false;
        }
    }
}

