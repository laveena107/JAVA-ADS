/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Labtask;

import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter your name:");
        String name = scanner.nextLine();

        if (isValidName(name)) {
            System.out.println("Valid name: " + name);
        } else {
            System.out.println("Invalid name. Please enter a valid name.");
        }

        scanner.close();
    }

    private static boolean isValidName(String name) {
        // Check if the name is not empty
        if (name.isEmpty()) {
            return false;
        }

        // Check if the name contains only letters and spaces
        for (char ch : name.toCharArray()) {
            if (!Character.isLetter(ch) && ch != ' ') {
                return false;
            }
        }

        // Additional custom validation rules can be added here if needed

        return true;
    }
}
