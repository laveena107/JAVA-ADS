/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask15;
import java.io.*;

public class Question8 implements Serializable {
    private String title;
    private String author;
    private String isbn; // The ISBN attribute

    public Question8(String title, String author, String isbn) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getIsbn() {
        return isbn;
    }

    public static void main(String[] args) {
        // Create a Book instance
        Question8 book = new Question8("Java Core & Advanced book", "Black Book", "1234567890");

        // Serialize the Book object to a file
        try (ObjectOutputStream outputStream = new ObjectOutputStream(new FileOutputStream("book.ser"))) {
            // Encrypt the ISBN before serialization
            book.encryptISBN();

            // Write the Book object to the file
            outputStream.writeObject(book);
            System.out.println("Book serialized and saved to file.");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Deserialize the Book object from the file
        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream("book.ser"))) {
            // Read the Book object from the file
            Question8 deserializedBook = (Question8) inputStream.readObject();

            // Decrypt the ISBN after deserialization
            deserializedBook.decryptISBN();

            // Print the deserialized book
            System.out.println("Deserialized Book: ");
            System.out.println("Title: " + deserializedBook.getTitle());
            System.out.println("Author: " + deserializedBook.getAuthor());
            System.out.println("ISBN: " + deserializedBook.getIsbn());
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    // Simple XOR encryption method
    private void encryptISBN() {
        char[] key = "SecretKey".toCharArray();
        char[] encrypted = new char[isbn.length()];
        for (int i = 0; i < isbn.length(); i++) {
            encrypted[i] = (char) (isbn.charAt(i) ^ key[i % key.length]);
        }
        isbn = new String(encrypted);
    }

    // Simple XOR decryption method
    private void decryptISBN() {
        encryptISBN(); // XOR encryption is its own inverse
    }
}
