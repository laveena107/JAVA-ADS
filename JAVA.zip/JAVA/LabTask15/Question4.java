/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask15;
import java.io.FileInputStream;
import java.io.IOException;
public class Question4 {
    
    
    void readFile() throws IOException{
        int i;
        try(FileInputStream fin=new FileInputStream("/Users/laveena/NetBeansProjects/cdac/src/LabTask15/source.txt")){ 
        do{
         i=fin.read();
            System.out.print((char)i);
        }while(i!=-1);
      }
      catch(Exception e){
          System.out.println(e.getMessage());
      }
    }
    
    
    
    public static void main(String[] args) throws IOException{
        Question4 q4 = new Question4();
        q4.readFile();
    }
}