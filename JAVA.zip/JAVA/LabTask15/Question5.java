/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask15;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;

public class Question5 {
    public static void main(String[] args) {
        try{
            Path path=Paths.get("/Users/laveena/NetBeansProjects/cdac/src/LabTask15/source.txt");
            
            String content="Soft Polynomials Pvt Ltd,Nagpur";
            for(int i=0;i<10;i++)
                Files.write(path,content.getBytes(),StandardOpenOption.APPEND);
            System.out.println("Completed");
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
}