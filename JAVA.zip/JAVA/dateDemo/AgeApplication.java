
package dateDemo;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.Period;
import java.util.*;

public class AgeApplication {
    public static void main(String[] args) {
//        System.out.println("Enter your Date of Birth 'date/month/year' : ");
//        Scanner sc = new Scanner(System.in);
//        String dob = sc.next();
//        String arr[]=dob.split("/");
//        
//        for(String s:arr)
//           System.out.println(s);

//        int d = Integer.parseInt(arr[0]);   
//        int m = Integer.parseInt(arr[1]); 
//        int y = Integer.parseInt(arr[2]); 
//        
//        LocalDate birthDate=LocalDate.of(y,m,d); 
        
     //   LocalDate  today = LocalDate.now();
       // System.out.println(today);
       //  LocalDateTime  today = LocalDateTime.now();
       LocalDate  today = LocalDate.now();
        System.out.println(today);
        System.out.println(today.minusMonths(6));
        System.out.println(today.minusWeeks(3));
        System.out.println(today.minusDays(2));
        System.out.println(today.plusWeeks(6));
        System.out.println(today.isAfter(today));
        System.out.println(today.isAfter(LocalDate.of(2021, 10, 23)));
        System.out.println(today.isBefore(today));
        System.out.println(today.getMonth());
        System.out.println(today.getMonthValue());
        System.out.println(today.getDayOfWeek());
        System.out.println(today.getDayOfMonth());
        System.out.println((char) today.getDayOfYear());
        
//        
//        Period p =Period.between(birthDate,today);
//        System.out.println("you are "+p.getYears()+" years, "+p.getMonths()+" months and "+p.getDays()+" days.");
        
    }

  
}
