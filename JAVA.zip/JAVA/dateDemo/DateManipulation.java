
package dateDemo;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateManipulation {
    public static void main(String[] args) throws ParseException {
//        Date d = new Date();
//       
//        SimpleDateFormat sdf= new SimpleDateFormat("dd MM,yyyy hh:mm:ss");
//        // for converting date to string
//        String strDate = sdf.format(d);
//         System.out.println(strDate);
         
         //for converting string to date 
         String sDate = "2023-10-23 8:35:45";
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
         
         try{
         Date dt = sdf.parse(sDate);
             System.out.println(dt);}
         catch(Exception e){
            
         }
         
         
         
    }
    
}
