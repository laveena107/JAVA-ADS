/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package overloading;

/**
 *
 * @author laveena
 */
public interface StudentInterface {
    int a=10; //by deafault public static final int a=10
    void showName(String name);//by default public abstract void showName
    void showAge(int Age);
    
    default void course(){
        System.out.println("Default Method of Interface");
    }
    
    static void institute(){
        System.out.println("This is static method");
    }
    
    private String exam(){
        return "CET";
    }
    private static String city(){
        return "Nagpur";
    }
}