
package overloading;

import java.util.Scanner;

public class DefaultParametrized {
    private String name;
    private int age;

    public DefaultParametrized() {
        this.name = "Laveena";
        this.age = 22;
    }

    public DefaultParametrized(String name, int age) {
        this.name = name;
        this.age = age;
    }

  

    
    public void displayDetails() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

  
        System.out.println("Using default constructor.");
        DefaultParametrized defaultP = new DefaultParametrized();
        System.out.println("Default Person Details:");
        defaultP.displayDetails();
        System.out.println();

        System.out.println("Using the parameterized constructor.");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter age: ");
        int age = scanner.nextInt();
        DefaultParametrized parameterizedP = new DefaultParametrized(name, age);
        System.out.println("Parameterized Person Details:");
        parameterizedP.displayDetails();
        System.out.println();

  
    }
}



