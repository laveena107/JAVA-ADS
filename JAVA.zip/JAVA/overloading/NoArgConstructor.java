
package overloading;
public class NoArgConstructor {
   
    private double o1;
    private double o2;

    
    public NoArgConstructor() {
      
        this.o1 = 0;
        this.o2 = 0;
    }

   
    public void setOperands(double o1, double o2) {
        this.o1 = o1;
        this.o2 = o2;
    }

    public double multiply() {
        return o1 * o2;
    }

    public static void main(String[] args) {

        NoArgConstructor m = new NoArgConstructor();

        m.setOperands(5.5, 3.0);
        double result = m.multiply();
        System.out.println("Multiplication Result: " + result);
    }
}
