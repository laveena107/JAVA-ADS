/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;

/**
 *
 * @author laveena
 */
public class Qs3 {
    int value;
    
    public Qs3(){
        value=0;
}
    
    public Qs3(int v){
        value=v;
    }
    
    int getValue(){
        return value;
    }
    
    public static void main(String[] args) {
        Qs3 p = new Qs3();
        System.out.println("Using Default Constructor: " + p.getValue());

        Qs3 p1 = new Qs3(42);
        System.out.println("Using Parameterized Constructor: " + p1.getValue());
    }
}