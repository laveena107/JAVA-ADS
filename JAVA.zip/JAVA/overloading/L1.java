/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;

/**
 *
 * @author laveena
 */
class Animal{
    public void sound(){
        System.out.println("sound");
    }
    protected void sleep(){
        System.out.println("sleeping");
    }
}
class Dog extends Animal{
    public void sound(){
        System.out.println("soundsss");
    }
}
public class L1 {
    public static void main(String[] args) {
        
    
    Dog dog = new Dog();
    dog.sound();
    dog.sleep();
    
}}
