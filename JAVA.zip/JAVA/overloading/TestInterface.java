/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;

/**
 *
 * @author laveena
 */
public class TestInterface {
    public static void main(String[] args) {
        StudentInterface si;
        si=new StudentImplementation();
        si.showAge(23);
        si.showName("Laveena");
        si.course();
        StudentInterface.institute();
    }
}
