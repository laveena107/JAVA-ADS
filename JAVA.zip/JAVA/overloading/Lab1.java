/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;


class Animal {
  
    public void makeSound() {
        System.out.println("Some generic sound");
    }

    
    protected void sleep() {
        System.out.println("Zzzzz");
    }
}

class Dog extends Animal {
   
    @Override
    public void makeSound() {
        System.out.println("Bark! Bark!");
    }

    
}

public class Lab1 {
    public static void main(String[] args) {
      
        Dog myDog = new Dog();

       
        myDog.makeSound(); 


        myDog.sleep();
    }
}
