
package overloading;

class Animal{
    void animalSound(){
        System.out.println("generic animal sound");
    }
    
}
class Dog extends Animal{
    void animalSound(){
        System.out.println("Dog Barks....");
    }
}
class Cat extends Animal{
    void animalSound(){
        System.out.println("Cat Meoww...");
    }
}
public class MethodOverriding {
    public static void main(String[] args) {
        
       /* Dog d = new Dog();
        Cat c = new Cat();
        d.animalSound();
        c.animalSound();*/
       Animal a;
      // a=new Animal();
      // a=new Dog();
       a=new Cat();
       a.animalSound();
    }
    
}
