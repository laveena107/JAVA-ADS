/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;

/**
 *
 * @author laveena
 */
import java.util.Scanner;

public class Parametrised {
   
    private String FirstName;
    private String LastName;


    public Parametrised() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the First Name: ");
        this.FirstName = scanner.next();

        System.out.print("Enter the Last Name: ");
        this.LastName = scanner.next();
    }

  
    public String getFirstName() {
        return FirstName;
    }

    public String getSecondName() {
        return LastName;
    }

  
    public static void main(String[] args) {
       
        Parametrised p = new Parametrised();

       
        System.out.println("First Name: " + p.getFirstName());
        System.out.println("Last Name: " + p.getSecondName());
    }
}
