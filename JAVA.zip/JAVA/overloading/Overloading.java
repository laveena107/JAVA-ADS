/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package overloading;
import java.util.*;
public class Overloading {
    void overload(String src, String via, String dest){
        System.out.println("Moving from "+src+" to "+dest+" via "+via);
    }
    void overload(String src, String dest){
        System.out.println("Moving from "+src+" to "+dest);
        
    }
    void overload(String dest){
        System.out.println("Moving to "+dest);
    }
    
    public static void main(String args[]){
        Overloading ol = new Overloading();
        System.out.println("Please enter : ");
        System.out.println("1. For destination only");
        System.out.println("2. For source and destination");
        System.out.println("3. for source, via and destination");
        
        Scanner s = new Scanner(System.in);
        Scanner s1 = new Scanner(System.in);
        
        int choice;
        choice = s1.nextInt();
        switch(choice){
            case 1:{
                System.out.println("Enter destination : ");
                String d = s.nextLine();
                ol.overload(d);
                break;}
            case 2:{
                System.out.println("Enter source and destination");
                String str = s.nextLine();
                String d = s.nextLine();
                ol.overload(str, d);
                break;}
            case 3:{
                System.out.println("Enter source, via and destination");
                String str = s.nextLine();
                String v = s.nextLine();
                String d = s.nextLine();
                ol.overload(str, v, d);
                break;}
                default:{
                    System.out.println("we dont serve at your location");}
        }
               
}}
    

