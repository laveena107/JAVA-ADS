/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pattern;


public class Student {
    private String name;

    public Student() {
        this.name = "Unknown";
    }

    public Student(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static void main(String[] args) {
       
        Student unknownStudent = new Student();
        System.out.println("Student Name: " + unknownStudent.getName());

      
        String studentName = "Laveena";
        Student namedStudent = new Student(studentName);
        System.out.println("Student Name: " + namedStudent.getName());
    }
}