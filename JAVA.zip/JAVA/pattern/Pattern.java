
package pattern;

import java.util.*;
public class Pattern {
    void  Equilateral(){
        int i,j,k,n;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the number of rows : ");
        n=s.nextInt();
        char c='A';
        for(i=0;i<=n;i++)
            for(j=n;j>=i;j--){
                System.out.print(" ");
            }
            for(k=1;k<=i;k++){
               // System.out.print("* ");
               //System.out.print(" "+i); // printing numbers
               // System.out.print(" "+k);
               System.out.print(" "+c);
            }
            c++;
            System.out.println();
        }
        
        
    
    public static void main(String[] args) {
        Pattern p = new Pattern();
        p.Equilateral();
    }
            
    
}
