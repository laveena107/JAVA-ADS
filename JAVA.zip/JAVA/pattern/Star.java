
package pattern;

public class Star {
    public static void main(String[] args) {
        
    
    int n = 11;
    for(int i=0;i<n;i++){
    for(int j=0;j<n;j++){
        if((i==0&&j==5)||(i==2&&j==10)||(i==1&&j==4)||(i==1&&j==6)||(i==2&&j==3)||(i==2&&j==7)||(i==2&&j==0)||(i==2&&j==1)||(i==2&&j==2)||(i==2&&j==8)||(i==2&&j==9)){
            System.out.println("*");
        }else{
            System.out.println(" ");
        }
    }
        System.out.println(" ");
}
    }
}
