
package pattern;

class Account{
    int accNo;
    String accType;

public Account(int an){

accNo=an;
accType="No Account";
}
public Account(int accNo,String accType){
    this.accNo=accNo;
    this.accType=accType;
}
void displayInfo(){
    System.out.println("your account no. is "+accNo+" and type is "+accType);
}}
public class BankAccount {
    public static void main(String[] args) {
        Account ac = new Account(1110022);
        ac.displayInfo();
        Account ac1 = new Account(1110022,"current");
        ac1.displayInfo();
    }
}
