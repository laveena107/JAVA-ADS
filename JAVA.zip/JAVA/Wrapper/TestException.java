/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Wrapper;

/**
 *
 * @author laveena
 */
public class TestException {
    int a=10;
    //int b =0;
    int b = 2;  //array Index out of bound exception
    int arr[]={1,2,378};
    

void display(){
    System.out.println("display");
}
void show(){
    try{
System.out.println("c");

System.out.println(a/b);
arr[2]=12;
System.out.println("d");
}
    catch(ArithmeticException | ArrayIndexOutOfBoundsException e){
    System.out.println(e.getMessage());
}
//catch(ArrayIndexOutOfBoundsException e){
//    System.out.println(e.getMessage());
//}
//catch(Exception e){
//    System.out.println(e.getMessage());
//}
finally{}}
        
    public static void main(String[] args) {
        System.out.println("a");
        TestException obj = new TestException();
        System.out.println("b");
        obj.show();
        System.out.println("E");
        obj.display();
    }
}