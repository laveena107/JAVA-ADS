/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thread.synchronization;

/**
 *
 * @author laveena
 */
public class SynchDemo implements Runnable{
   static int x;

    @Override
    public void run() {
        synchronized (this){
            
        
        for(int i=0;i<1000;i++){
            x++;
            x--;
        }
        }
    }
     public static void main(String[] args) {
         SynchDemo sd = new SynchDemo();
         Thread th[]=new Thread[100];
         for(int i=0;i<th.length;i++){
             th[i]=new Thread(sd);
             th[i].start();
             
         }
         System.out.println("final value of x is = "+x);
        
    }
}
