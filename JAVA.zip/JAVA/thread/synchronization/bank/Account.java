/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thread.synchronization.bank;

/**
 *
 * @author laveena
 */
public class Account {
    private int balance = 10000;
    
    public boolean isSufficientBalance(int amount){
        if(balance < amount)
            return false;
        else 
            return true;
    }
    
    public void  withdraw(int amount){
        
        balance = balance-amount;
        System.out.println("Remaining balance is INR "+balance+"/-");
    }
    
    
}
