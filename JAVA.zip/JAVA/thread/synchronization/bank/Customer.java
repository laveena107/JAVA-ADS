/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thread.synchronization.bank;

import java.util.Scanner;

/**
 *
 * @author laveena
 */
public class Customer implements Runnable {
    private String name;
    private Account account;

    public Customer(String name, Account account) {
        this.name = name;
        this.account = account;
    }
    

    @Override
    public void run() {
        synchronized(account){
        Scanner sc = new Scanner(System.in);
        System.out.println("Dear "+name+" Please enter amount to withdraw");
        int amount = sc.nextInt();
        
        if(account.isSufficientBalance(amount)){
            System.out.println(this.name+" is going to withdraw INR "+amount+"/-");
            
                 
            account.withdraw(amount);
        }
        else{
            System.out.println("Insufficient balance....");
            
            
        }}
    
    }
}
