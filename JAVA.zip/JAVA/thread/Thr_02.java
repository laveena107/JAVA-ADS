/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package thread;

/**
 *
 * @author laveena
 */
public class Thr_02 implements Runnable{

    String name;

    public Thr_02(String name) {
        this.name=name;
         }
    
    @Override
    public void run() {
        for(int i=0;i<9;i++){
            System.out.println(this.name + i);
            
        }
       
    }
    public static void main(String[] args) {
        Thr_02 t1=new Thr_02("One");
         Thr_02 t2=new Thr_02("Two");
         
         Thread th1 = new Thread();
         Thread th2 = new Thread();
         
         th1.start();
         th2.start();
    }
    
    
}
