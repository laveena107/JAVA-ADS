
package thread.deadlock;

import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DeadLockDemo {
    public static void main(String[] args) {
        String rec1="Laveena";
        String rec2 = "Atishay";
        Thread t1 = new Thread(){
            @Override
            public void run() {
                synchronized(rec1){
                System.out.println("thread 1 uses resource 1 "+rec1);
                    try {
                        sleep(100);
                    } catch (Exception ex) {
                        
                    }
                synchronized(rec2){
                 System.out.println("thread 1 uses resource 2 "+rec2);
                }}
            }
        };
        Thread t2 = new Thread(){
            @Override
            public void run() {
                synchronized(rec2){
                System.out.println("thread 2 uses resource 1 "+rec1);
                    try {
                        sleep(100);
                    } catch (Exception ex) {
                        
                    }
                synchronized(rec1){
                 System.out.println("thread 2 uses resource 2 "+rec2);
                }}
            }
        };
        t1.start();
        t2.start();
        
    }
    
}
