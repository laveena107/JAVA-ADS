/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask17;
import java.util.ArrayList;
import java.util.Collections;

public class Question5 {
    public static void main(String[] args) {
        // Create an ArrayList of integers
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(5);
        numbers.add(2);
        numbers.add(9);
        numbers.add(1);
        numbers.add(6);

        // Sort the ArrayList
        Collections.sort(numbers);

        // Display the sorted ArrayList
        System.out.println("Sorted ArrayList: " + numbers);
    }
}
