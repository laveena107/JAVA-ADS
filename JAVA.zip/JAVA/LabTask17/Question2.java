/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask17;
import java.util.ArrayList;
import java.util.Iterator;

public class Question2 {
    public static void main(String[] args) {
   
        ArrayList<Integer> numbers = new ArrayList<>();

        numbers.add(10);
        numbers.add(40);
        numbers.add(50);

        
        System.out.println("Using a for-each loop:");
        for (int number : numbers) {
            System.out.println(number);
        }

        System.out.println("\nUsing an Iterator:");
        Iterator<Integer> iterator = numbers.iterator();
        while (iterator.hasNext()) {
            int number = iterator.next();
            System.out.println(number);
        }
    }
}
