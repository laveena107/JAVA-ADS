/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask17;
import java.util.ArrayList;
import java.util.List;

public class Question1 {
    public static void main(String[] args) {
       
        ArrayList<String> colors = new ArrayList<>();

       
        colors.add("Red");
        colors.add("Blue");
        colors.add("Purple");


        System.out.println("List of Colors:");
        for (String color : colors) {
            System.out.println(color);
        }
    }
}
