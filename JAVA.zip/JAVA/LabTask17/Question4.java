/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask17;
import java.util.ArrayList;

public class Question4 {
    public static void main(String[] args) {
        // Create an ArrayList
        ArrayList<String> arrayList = new ArrayList<>();

        // Add some elements to the ArrayList
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Cherry");
        arrayList.add("Date");
        arrayList.add("Elderberry");

        // Specify the index of the element you want to retrieve
        int indexToRetrieve = 2; // Change this to the desired index

        // Check if the index is valid
        if (indexToRetrieve >= 0 && indexToRetrieve < arrayList.size()) {
            // Retrieve the element at the specified index
            String element = arrayList.get(indexToRetrieve);
            System.out.println("Element at index " + indexToRetrieve + ": " + element);
        } else {
            System.out.println("Invalid index. Index must be between 0 and " + (arrayList.size() - 1));
        }
    }
}
