
package LabTask17;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Question6 {
    public static void main(String[] args) {
        // Create an ArrayList of wrapper classes
        List<Integer> integerList = new ArrayList<>();
        List<Double> doubleList = new ArrayList<>();
        List<Character> charList = new ArrayList<>();

        // Insert elements
        integerList.add(42);
       
        doubleList.add(3.14);
       
        charList.add('A');
      

        // Display the lists
        System.out.println("Integer List: " + integerList);
        System.out.println("Double List: " + doubleList);
        System.out.println("Character List: " + charList);

        // Search for an element
        int searchValue = 15;
        if (integerList.contains(searchValue)) {
            System.out.println("Found " + searchValue + " in Integer List.");
        } else {
            System.out.println(searchValue + " not found in Integer List.");
        }

        // Delete an element
        char charToRemove = 'B';
        if (charList.contains(charToRemove)) {
            charList.remove(Character.valueOf(charToRemove));
            System.out.println("Removed " + charToRemove + " from Character List.");
        } else {
            System.out.println(charToRemove + " not found in Character List.");
        }

        // Iterate through the lists
        System.out.println("Iterating through Integer List:");
        for (Integer num : integerList) {
            System.out.print(num + " ");
        }
        System.out.println(); // New line for separation

        System.out.println("Iterating through Double List:");
        for (Double num : doubleList) {
            System.out.print(num + " ");
        }
        System.out.println();

        System.out.println("Iterating through Character List:");
        for (Character ch : charList) {
            System.out.print(ch + " ");
        }
        System.out.println();

        // Sort the lists
        Collections.sort(integerList);
        Collections.sort(doubleList);
        Collections.sort(charList);

        System.out.println("Sorted Integer List: " + integerList);
        System.out.println("Sorted Double List: " + doubleList);
        System.out.println("Sorted Character List: " + charList);
    }
}
