
package LabTask17;
import java.util.ArrayList;

public class Question3 {
    public static void main(String[] args) {

        ArrayList<String> arrayList = new ArrayList<>();

      
        arrayList.add("Laveena");
        arrayList.add("Atishay");
          arrayList.add("Purti");
    
        System.out.println("Original ArrayList: " + arrayList);

      
        String elementToInsert = "Parul";

        arrayList.add(0, elementToInsert);

        System.out.println("Updated ArrayList: " + arrayList);
    }
}
