package labtask11;
public class Question6 {
    public static void main(String[] args) {
        String input = "My name is Atishay Jain";
        String result = input.replace(" ", "");
        System.out.println("Original string: " + input);
        System.out.println("String without spaces: " + result);
    }
}
