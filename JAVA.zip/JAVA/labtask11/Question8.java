package labtask11;
public class Question8 {
    public static void main(String[] args) {
        String text = "My name is Atishay Jain.";

        int length = text.length();

        System.out.println("The string is: " + text);
        System.out.println("The length of the string is: " + length);
    }
}
