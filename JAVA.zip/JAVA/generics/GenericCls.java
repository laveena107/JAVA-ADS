
package generics;
class Container<T,V>{
    T contain;
    private V data;

    public Container(T contain) {
        this.contain = contain;
    }

    public T getContain() {
        return contain;
    }
    public V showData(<? super V> data){
        return data;
    }
    
    public void showType(){
        System.out.println(contain.getClass().getName());
    }
}
public class GenericCls {
    public static void main(String[] args) {
        Container<String,Integer> c = new Container<>("cdac");
        String s = c.getContain();
        
        System.out.println(c.getContain());
       
        System.out.println(c.showData(107));
        
         c.showType();
        
        
    }
    
}





















//
//
//class Container{
//    Object contain;
//
//    public Container(Object contain) {
//        this.contain = contain;
//    }
//
//    public Object getContain() {
//        return contain;
//    }
//    
//    public void showType(){
//        System.out.println(contain.getClass().getName());
//    }
//}
//public class GenericCls {
//    public static void main(String[] args) {
//        Container c = new Container("cdac");
//        String s =(String)c.getContain();
//        System.out.println(c.getContain());
//        c.showType();
//        
//        
//        
//    }
//    
//}
