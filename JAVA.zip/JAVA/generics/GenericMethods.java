
package generics;

import java.util.List;

public class GenericMethods {

//  
////    public static  void <E> showData(List<E> lst){      
////wildcard . // super - lower bound extends - upper bound
////        for(E s:lst)
////            System.out.println(s);
////      
////    }
  
       public static <E> void showData(E arr[]){ // generic method 
        for(E s:arr)
            System.out.println(s);
    }
//    public static void showData(Integer arr[]){       //method overloading
//        for(Integer s:arr)
//            System.out.println(s);
//    }
//        
    public static void main(String[] args) {
//        String names[]={"Laveena","Atishay","Parul","Purti"};
//        Integer ages[]={22,23,24,29};
//        showData(names);
//        showData(ages);
List lst1=List.of("Laveena","Atishay","Parul","Purti");
List lst2=List.of(22,23,24,29);
//showData(lst1);
//showData(lst2);
//        
    }
    
}
