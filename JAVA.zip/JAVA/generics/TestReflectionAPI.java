
package generics;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat.Field;

class Person{
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
    
    private void showInfo(){
        System.out.println("HELLO "+name+" YOU ARE "+age+" OLD...");
    }
}

public class TestReflectionAPI {
    
    public static void main(String[] args) throws NoSuchMethodException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException {
        //create class reference 
        Class personCls=Person.class;
        
        Constructor  cons = personCls.getDeclaredConstructor(String.class,int.class);
        Object object = cons.newInstance("LAVEENA",22);
        
        java.lang.reflect.Field fname = personCls.getDeclaredField("name");
        fname.setAccessible(true);          //access private properties
        fname.set(object,"LAVEENA");
        Method m = personCls.getDeclaredMethod("showInfo");
        m.setAccessible(true);
        m.invoke(object);
        
        String s = (String) fname.get(object);
        System.out.println(s);
        
        java.lang.reflect.Field fage = personCls.getDeclaredField("age");
        fage.setAccessible(true);
        int a = fage.getInt(object);System.out.println(a);
        
        
        
    }
    
    

}
