
package Arrays;

import java.util.Scanner;

public class Question6 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Declare an array to store elements
        int[] array = new int[size];

        // Take input for each element of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

        // Ask the user for the element to find its frequency
        System.out.print("Enter the element to find its frequency: ");
        int targetElement = scanner.nextInt();

        // Call the function to calculate the frequency
        int frequency = findFrequency(array, targetElement);

        // Display the result
        System.out.println("Frequency of " + targetElement + ": " + frequency);

        // Close the Scanner
        scanner.close();
    }

    // Function to calculate the frequency of an element in an array
    private static int findFrequency(int[] array, int target) {
        int frequency = 0;
        for (int number : array) {
            if (number == target) {
                frequency++;
            }
        }
        return frequency;
    }
}
