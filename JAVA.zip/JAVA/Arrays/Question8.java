/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arrays;
import java.util.Scanner;

public class Question8 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Declare an array to store elements
        int[] array = new int[size];

        // Take input for each element of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

        // Call the function to count odd and even numbers
        int countOdd = countOddNumbers(array);
        int countEven = countEvenNumbers(array);

        // Display the results
        System.out.println("Number of odd numbers: " + countOdd);
        System.out.println("Number of even numbers: " + countEven);

        // Close the Scanner
        scanner.close();
    }

    // Function to count the number of odd numbers in an array
    private static int countOddNumbers(int[] array) {
        int count = 0;
        for (int number : array) {
            if (number % 2 != 0) {
                count++;
            }
        }
        return count;
    }

    // Function to count the number of even numbers in an array
    private static int countEvenNumbers(int[] array) {
        int count = 0;
        for (int number : array) {
            if (number % 2 == 0) {
                count++;
            }
        }
        return count;
    }
}
