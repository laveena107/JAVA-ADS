package Arrays;
public class Question7 {
    public static void main(String[] args) {
        int[] sortedArray = {1, 1, 2, 2, 3, 4, 4, 5, 5};

        // Call the removeDuplicates function to remove duplicates
        int newSize = removeDuplicates(sortedArray);

        // Display the array after removing duplicates
        System.out.println("Array after removing duplicates:");
        for (int i = 0; i < newSize; i++) {
            System.out.print(sortedArray[i] + " ");
        }
    }

    // Function to remove duplicates from a sorted array
    private static int removeDuplicates(int[] nums) {
        if (nums.length == 0) {
            return 0;
        }

        int newSize = 1;

        for (int i = 1; i < nums.length; i++) {
            if (nums[i] != nums[i - 1]) {
                nums[newSize] = nums[i];
                newSize++;
            }
        }

        return newSize;
    }
}
