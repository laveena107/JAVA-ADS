
package Arrays;
import java.util.Scanner;

public class Question9 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Declare an array to store elements
        int[] arr = new int[size];

        // Take input for each element of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            arr[i] = scanner.nextInt();
        }

        // Call the function to calculate the minimum number of swaps
        int minSwaps = minimumSwaps(arr);

        // Display the result
        System.out.println("Minimum number of swaps to sort the array: " + minSwaps);

        // Close the Scanner
        scanner.close();
    }

    // Function to calculate the minimum number of swaps to sort an array
    private static int minimumSwaps(int[] arr) {
        int n = arr.length;
        int swaps = 0;

        // Iterate through the array
        for (int i = 0; i < n - 1; i++) {
            // Find the minimum element's index in the remaining unsorted part of the array
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }

            // Swap the found minimum element with the current element
            if (minIndex != i) {
                int temp = arr[i];
                arr[i] = arr[minIndex];
                arr[minIndex] = temp;
                swaps++;
            }
        }

        return swaps;
    }
}
