/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arrays;
import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Declare an array to store 10 integers
        int[] numbers = new int[10];

        // Take 10 integer inputs from the user and store them in the array
        System.out.println("Enter 10 integers:");

        for (int i = 0; i < 10; i++) {
            System.out.print("Enter number " + (i + 1) + ": ");
            numbers[i] = scanner.nextInt();
        }

        // Ask the user to enter a number to search for
        System.out.print("Enter a number to search for: ");
        int searchNumber = scanner.nextInt();

        // Call the search function to check if the number is present in the array
        boolean isNumberPresent = searchInArray(numbers, searchNumber);

        // Display the result to the user
        if (isNumberPresent) {
            System.out.println(searchNumber + " is present in the array.");
        } else {
            System.out.println(searchNumber + " is not present in the array.");
        }

        // Close the Scanner
        scanner.close();
    }

    // Function to search for a number in the array
    private static boolean searchInArray(int[] array, int target) {
        for (int number : array) {
            if (number == target) {
                return true; // Number found
            }
        }
        return false; // Number not found
    }
}
