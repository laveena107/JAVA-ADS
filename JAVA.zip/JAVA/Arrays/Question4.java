
package Arrays;
import java.util.Scanner;

public class Question4 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user for the size of the array
        System.out.print("Enter the size of the array: ");
        int size = scanner.nextInt();

        // Declare an array to store elements
        int[] array = new int[size];

        // Take input for each element of the array
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element " + (i + 1) + ": ");
            array[i] = scanner.nextInt();
        }

        // Call functions to calculate sum and product
        int sum = calculateSum(array);
        long product = calculateProduct(array);

        // Display the results
        System.out.println("Sum of elements: " + sum);
        System.out.println("Product of elements: " + product);

        // Close the Scanner
        scanner.close();
    }

    // Function to calculate the sum of elements in an array
    private static int calculateSum(int[] array) {
        int sum = 0;
        for (int number : array) {
            sum += number;
        }
        return sum;
    }

    // Function to calculate the product of elements in an array
    private static long calculateProduct(int[] array) {
        long product = 1;
        for (int number : array) {
            product *= number;
        }
        return product;
    }
}
