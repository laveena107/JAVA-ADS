/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Arrays;
public class Question5 {
    public static void main(String[] args) {
        int[] arr1 = {1, 3, 5, 7, 9};
        int[] arr2 = {2, 4, 6, 8, 10};

        // Call the mergeArrays function to merge the two sorted arrays
        int[] mergedArray = mergeArrays(arr1, arr2);

        // Display the merged array
        System.out.println("Merged Sorted Array:");
        for (int num : mergedArray) {
            System.out.print(num + " ");
        }
    }

    // Function to merge two sorted arrays into a new sorted array
    private static int[] mergeArrays(int[] arr1, int[] arr2) {
        int len1 = arr1.length;
        int len2 = arr2.length;
        int[] result = new int[len1 + len2];

        int i = 0, j = 0, k = 0;

        // Compare elements of both arrays and merge them in sorted order
        while (i < len1 && j < len2) {
            if (arr1[i] <= arr2[j]) {
                result[k++] = arr1[i++];
            } else {
                result[k++] = arr2[j++];
            }
        }

        // Copy the remaining elements of arr1, if any
        while (i < len1) {
            result[k++] = arr1[i++];
        }

        // Copy the remaining elements of arr2, if any
        while (j < len2) {
            result[k++] = arr2[j++];
        }

        return result;
    }
}
