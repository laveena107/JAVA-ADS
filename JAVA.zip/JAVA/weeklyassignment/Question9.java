
package weeklyassignment;
public class Question9 {
    public static void main(String[] args) {
        int size = 7; 
        char ch1 = 'L';
        char ch2 = 'D';

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if ((j == 0) || (i==6 && j == 0) || (i==6 && j == 1)||(i==6 && j == 2)||(i==6 && j == 3)||(i==6 && j == 4)||(i==6 && j == 5)) {
                    System.out.print(" "+ch1);
                } else {
                    System.out.print("  ");
                }
            }
            System.out.print("  ");
            for (int j = 0; j <=size; j++) {
                if (j == 0 || (i==0 && j==1) || (i==0 && j==2) || (i==0 && j==3)  || (i==6 && j==1) || (i==6 && j==2) || (i==6 && j==3) || (i==1 && j==6) || (i==5 && j==6) || (i==2 && j==7) || (i==3 && j==7) || (i==4 && j==7) ) {
                    System.out.print(" "+ch2);
                } else {
                    System.out.print(" ");
                }
            }

            System.out.println();
        }
    }
}