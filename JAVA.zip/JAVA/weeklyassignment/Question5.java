
package weeklyassignment;

class Animal {
    void makeSound() {
        System.out.println("Animal sound");
    }
}

class Dog extends Animal {
    void makeSound() {
        System.out.println("Dog barks");
    }

    void fetch() {
        System.out.println("Dog fetches ball");
    }
}

public class Question5 {
    public static void main(String[] args) {
       
        Animal animal = new Dog(); 

      
        animal.makeSound(); 

       
        if (animal instanceof Dog) {
            Dog dog = (Dog) animal; 
            dog.fetch();
        } else {
            System.out.println("Animal is Dog");
        }
    }
}

