/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObjectInsideMethod;

public class ConstantPool {
    public static void main(String[] args) {
//          Byte b1 = Byte.valueOf("-128");
//          Byte b2 = Byte.valueOf("-128");
//        
//          Short b1 = Short.valueOf("128");
//          Short b2 = Short.valueOf("128");


//          Boolean b1 = Boolean.valueOf("false");
//          Boolean b2 = Boolean.valueOf("flase");
//          System.out.println(b1==b2);
            
            
            
            
             Character b1 = Character.valueOf('\u0950');
        
    }
}

