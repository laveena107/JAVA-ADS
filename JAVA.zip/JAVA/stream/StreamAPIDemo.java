
package stream;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamAPIDemo {
    public static void main(String[] args) {
       // List<String> lst = List.of("Laveena","Atishay","Parul","Purti","Purnita","priya");
        
//        for(String s:lst){
//            System.out.println(s);
//            
//        }
//        System.out.println("-------------------------------------------------------------");
//       // lst.stream().forEach(e->System.out.println(e));
//       //method reference
//         lst.stream().forEach(System.out::println);
//         
         List<Integer> lst = List.of(1,2,2, 3,4,5,6);
        System.out.println(lst);
//        List<Integer> evenlst = lst.stream().filter(i->i%2==0).collect(Collectors.toList());
//         System.out.println(evenlst);
       //   lst.stream().filter(i->i%2==0).collect(Collectors.toList()).forEach(System.out::println());
        // lst.stream().map(i->i+5).forEach(System.out::println);
       // lst.stream().map(i->i+5).collect(Collectors.toSet());
      //  lst.stream().sorted((x,y->y.compareTo(x)).forEach(System.out::println());
        
//        Integer i =  lst.stream().max((x,y->x.compareTo(y)).get();
//        System.out.println(i);
String arr[] = {"Laveena","Atishay"};
Arrays.stream(arr).filter(e->e.startsWith("A")).forEach(System.out::println);

    }
}
