/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package objectMethod;

import java.util.LinkedHashSet;
import java.util.Objects;

/**
 *
 * @author laveena
 */
class Student {
    private String name;
    private int age;
    public Student(String name, int age){
        this.name = name;
        this.age=age;
        
             
    }

//    @Override
//    public int hashCode() {
//        return this.age;
//    }

    @Override
    public String toString() {        //represent object in string format according to the requirement 
        return "Student{" + "name=" + name + ", age=" + age + '}'+"\n";
        
        
    }    

    @Override
    public boolean equals(Object obj) {
        Student stud = (Student)obj; //downcasting
        return this.name.equals(stud.name) && this.age==stud.age;
    }
}
public class TestEqHasTostr {
    public static void main(String[] args) {
        Student s1 = new Student("Laveena",22);
        Student s2 = new Student("Atishay",23);
        Student s3 = new Student("Laveena",22);
        Student s4 = new Student("Parul",2);
      //  System.out.println(s.toString());
      //  System.out.println(s==s1);
      //  System.out.println(s.equals(s1));
//        System.out.println(s.toString());
//        System.out.println(s.hashCode());
        

LinkedHashSet<Student> studs = new LinkedHashSet<>();
studs.add(s1);
studs.add(s2);
studs.add(s3);
studs.add(s4);
System.out.println(studs);
    }
}
