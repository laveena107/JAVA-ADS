package collection;

import java.util.ArrayList;

public class DemoArrayList_01 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        list.add(23);
        list.add(12);
        list.add(22);
        list.add(14);
        list.add(62);
        System.out.println(list);
    }
}
