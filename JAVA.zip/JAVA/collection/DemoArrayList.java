/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package collection;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class DemoArrayList {
    public static void main(String[] args) {
//        List lst1= new ArrayList();
//        lst1.add('1');
//        lst1.add('2');
//        lst1.add('3');
        List lst= new ArrayList();
//        lst.add('D');
//        lst.add('A');
//        lst.add('B');
//        lst.add('D');
//        lst.add(3,'C');
//        lst.remove(0);
//        lst.addAll(0,lst1);
//        //lst.remove('D');
//        System.out.println(lst.get(3));
//        System.out.println(lst.contains('B'));
//        System.out.println(lst);
lst.add(23);
lst.add(12.23);
lst.add("soft Polynomials");
lst.add(new Date());
       // System.out.println(lst);
       
       for(Object o:lst){
           System.out.println(o);
       }
        System.out.println("*******************************");
       Iterator it = lst.iterator(); //object cant be created
       while(it.hasNext())
            System.out.println(it.next());
       
    }
    
}
