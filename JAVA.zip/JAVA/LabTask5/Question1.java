
package LabTask5;
class MyClass {
    private int number;

    
    public MyClass() {
        number = 10; 
    }

    public void displayNumber() {
        System.out.println("Number is: " + number);
    }
}

public class Question1 {
    public static void main(String[] args) {
         MyClass obj = new MyClass();
          obj.displayNumber();
    }
}
