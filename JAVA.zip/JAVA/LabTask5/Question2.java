
package LabTask5;
class MyNumbers {
    private int number1;
    private int number2;

    public MyNumbers(int num1, int num2) {
        this.number1 = num1;
        this.number2 = num2;
    }

    public void displayNumbers() {
        System.out.println("Number 1: " + number1);
        System.out.println("Number 2: " + number2);
    }
}

public class Question2 {
    public static void main(String[] args) {
       MyNumbers numbers = new MyNumbers(10, 20);

        numbers.displayNumbers();
    }
}
