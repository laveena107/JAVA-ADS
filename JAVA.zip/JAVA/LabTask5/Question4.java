
package LabTask5;
public class Question4 {
    private String name;

   public Question4() {
        this.name = "Laveena";
    }

    public Question4(String name) {
        this.name = name;
    }

 
    public String getName() {
        return name;
    }

    public static void main(String[] args) {
        Question4 student1 = new Question4(); 
        Question4 student2 = new Question4("Atishay");

      
        System.out.println("Student 1 name: " + student1.getName());
        System.out.println("Student 2 name: " + student2.getName()); 
    }
}
