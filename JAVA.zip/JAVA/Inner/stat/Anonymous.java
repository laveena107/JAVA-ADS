/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inner.stat;

/**
 *
 * @author laveena
 */
class ParentOfAnonymous{
    void greeting(){
        System.out.println("Hello!!!!!");
    }
}
class OuterOfAnonymous{
    ParentOfAnonymous p = new ParentOfAnonymous(){
        @Override
        void greeting() {
            System.out.println("Good morning!!!!!");
        }
        
    };
    
}
public class Anonymous {
    public static void main(String[] args) {
        
    
        OuterOfAnonymous o = new OuterOfAnonymous();
        o.p.greeting();
    
    }
}
