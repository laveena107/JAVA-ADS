/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inner.stat;

/**
 *
 * @author laveena
 */
class Outer{
    int x=10;
    class Inner{
        int y=20;
        
        void display(){
            System.out.println("non static inner class"+(x+y));
        }
        
    }
}
public class TestNonStaticInnerCls {
    public static void main(String[] args) {
        
    
    Outer o = new Outer();
    Outer.Inner obj = o.new Inner();
    
    obj.display();
    }
}
