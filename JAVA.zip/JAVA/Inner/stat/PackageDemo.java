/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inner.stat;

/**
 *
 * @author laveena
 */
public class PackageDemo {
    public static void main(String[] args) {
        
    
    Inner.stat.pack1.TestPackageDemo tdp = new Inner.stat.pack1.TestPackageDemo();
    Inner.stat.pack2.TestPackageDemo tdp1 = new Inner.stat.pack2.TestPackageDemo();
    tdp.show();
    tdp1.show();
}}



