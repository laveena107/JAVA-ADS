/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Inner.stat;

/**
 *
 * @author laveena
 */
class Outer{
    int x=10;
    static class InnerStatic{
        int y=20;
        void show(){
                Outer o =new Outer();
                
            System.out.println("static inner class"+(o.x+y));
        }
    }
}
public class TestStaticInnerCls {
    public static void main(String[] args) {
        Outer.InnerStatic obj = new Outer.InnerStatic();
        obj.show();
        
    }
}
