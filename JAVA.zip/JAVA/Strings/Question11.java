/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strings;
public class Question11 {
    public static void main(String[] args) {
        String inputString = "Hello, have a good day";

        // Call the function to remove consonants
        String result = removeConsonants(inputString);

        // Display the result
        System.out.println("String after removing consonants: " + result);
    }

    // Function to remove consonants from a string
    private static String removeConsonants(String str) {
        // Using regular expression to replace consonants with an empty string
        return str.replaceAll("[bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ]", "");
    }
}
