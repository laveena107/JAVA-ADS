/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strings;

import java.util.Scanner;

public class Question10 {
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to input a string of alphabets
        System.out.print("Enter a string of alphabets: ");
        String inputString = scanner.nextLine().toLowerCase(); // Convert to lowercase for case-insensitivity

        // Call the function to count alphabet occurrences
        int[] occurrences = countAlphabetOccurrences(inputString);

        // Display the occurrences of each alphabet
        System.out.println("Occurrences of each alphabet:");
        for (char ch = 'a'; ch <= 'z'; ch++) {
            if (occurrences[ch - 'a'] > 0) {
                System.out.println(ch + ": " + occurrences[ch - 'a']);
            }
        }

        // Find the alphabet with the maximum occurrence
        char maxOccurrenceChar = findMaxOccurrenceAlphabet(occurrences);

        // Display the alphabet with the maximum occurrence
        System.out.println("Alphabet with maximum occurrence: " + maxOccurrenceChar);

        // Close the Scanner
        scanner.close();
    }

    // Function to count the occurrences of each alphabet in a string
    private static int[] countAlphabetOccurrences(String str) {
        int[] occurrences = new int[26]; // Assuming input only contains lowercase alphabets

        for (char ch : str.toCharArray()) {
            if (Character.isLetter(ch)) {
                occurrences[ch - 'a']++;
            }
        }

        return occurrences;
    }

    // Function to find the alphabet with the maximum occurrence
    private static char findMaxOccurrenceAlphabet(int[] occurrences) {
        char maxChar = 'a';
        int maxCount = occurrences[0];

        for (int i = 1; i < occurrences.length; i++) {
            if (occurrences[i] > maxCount) {
                maxCount = occurrences[i];
                maxChar = (char) ('a' + i);
            }
        }

        return maxChar;
    }
}

