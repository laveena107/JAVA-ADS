/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strings;
import java.util.Scanner;

public class Question12
{
    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Ask the user to input a string
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();

        // Call the function to reverse the words
        String reversedString = reverseWords(inputString);

        // Display the result
        System.out.println("String after reversing words: " + reversedString);

        // Close the Scanner
        scanner.close();
    }

    // Function to reverse the words in a string
    private static String reverseWords(String str) {
        // Split the string into words using space as the delimiter
        String[] words = str.split(" ");

        // Create a StringBuilder to build the reversed string
        StringBuilder reversedStringBuilder = new StringBuilder();

        // Iterate through the words in reverse order and append to the StringBuilder
        for (int i = words.length - 1; i >= 0; i--) {
            reversedStringBuilder.append(words[i]);
            if (i > 0) {
                reversedStringBuilder.append(" "); // Add a space between words
            }
        }

        // Convert the StringBuilder to a String
        return reversedStringBuilder.toString();
    }
}
