
package LabTask3;
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = scanner.nextInt();

        if (number % 8 == 0 && number % 5 == 0) {
            System.out.println(number + " is divisible by both 8 and 5");
        } else if (number % 8 == 0) {
            System.out.println(number + " is divisible by 8");
        } else if (number % 5 == 0) {
            System.out.println(number + " is divisible by 5");
        } else {
            System.out.println(number + " is divisible neither by 8 nor by 5");
        }

        scanner.close();
    }
}
