
package LabTask3;
public class Question8 {
    public static void main(String[] args) {
        int[][] firstMatrix = { {1, 2, 3}, {4, 5, 6} };
        int[][] secondMatrix = { {7, 8}, {9, 10}, {11, 12} };

        int rowsFirst = firstMatrix.length;
        int columnsFirst = firstMatrix[0].length;
        int columnsSecond = secondMatrix[0].length;

       
        int[][] result = new int[rowsFirst][columnsSecond];

        if (columnsFirst == secondMatrix.length) {
            for (int i = 0; i < rowsFirst; i++) {
                for (int j = 0; j < columnsSecond; j++) {
                    for (int k = 0; k < columnsFirst; k++) {
                        result[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
                    }
                }
            }

            System.out.println("Resultant Matrix after multiplication:");
            for (int i = 0; i < rowsFirst; i++) {
                for (int j = 0; j < columnsSecond; j++) {
                    System.out.print(result[i][j] + " ");
                }
                System.out.println();
            }
        } else {
            System.out.println("Matrix multiplication is not possible.");
        }
    }
}
