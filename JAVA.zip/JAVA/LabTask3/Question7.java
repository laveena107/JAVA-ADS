/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package LabTask3;
public class Question7 {
    public static void main(String[] args) {
        // Sample array
        int[] arr = {5, 10, 15, 20, 25};

        int sum = 0;

       
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }

        System.out.println("The sum of the array elements is: " + sum);
    }
}
