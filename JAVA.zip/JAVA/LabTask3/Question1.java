
package LabTask3;
import java.util.Scanner;

public class Question1 {
    public static void main(String[] args) {
        int totalMarks = 250; 

        Scanner scanner = new Scanner(System.in);
        int[] marks = new int[5];
        
      
        for (int i = 0; i < 5; i++) {
            System.out.print("Enter marks obtained in paper " + (i + 1) + ": ");
            marks[i] = scanner.nextInt();
        }

        int totalObtainedMarks = 0;
        for (int mark : marks) {
            totalObtainedMarks += mark;
        }

        double percentage = (totalObtainedMarks / (double) totalMarks) * 100;

        System.out.println("Total marks obtained: " + totalObtainedMarks);
        System.out.println("Percentage: " + percentage + "%");

     
        String grade;
        if (percentage >= 90) {
            grade = "A+";
        } else if (percentage >= 80) {
            grade = "A";
        } else if (percentage >= 70) {
            grade = "B+";
        } else if (percentage >= 60) {
            grade = "B";
        } else if (percentage >= 50) {
            grade = "C";
        } else {
            grade = "Fail";
        }

        System.out.println("Grade: " + grade);

        scanner.close();
    }
}

